const express = require("express");
const app = express();
const PORT = process.env.PORT || 4000;
const fileUpload = require("express-fileupload");

//Cookies
const cookieParser = require("cookie-parser");
app.use(cookieParser());



//Allow cors
const cors = require("cors");
//Loop of allowed origins
const allowedOrigins = ["http://localhost:3001", "http://localhost:3000"];

app.use(
  cors({
    origin: allowedOrigins,
    credentials: true,
  })
);

// Enable file upload using express-fileupload
app.use(
  fileUpload({
    createParentPath: true,
  })
);

//Server accept JSON
app.use(express.json());

//Connect to database
const connectDB = require("./config/database");
connectDB();

//Send html file
app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});
//Create User API
const users = require("./routes/users");
app.use("/api/users", users);

//Request and responce for login user
const login = require("./routes/login");
app.use("/api/login", login);

//Request and responce for Category
const category = require("./routes/category");
app.use("/api/categories", category);

//Request and responce for Notes
const note = require("./routes/note");
app.use("/api/note", note);

//Request and responce for Notes
const products = require("./routes/products");
app.use("/api/products", products);

//Request and responce for Files
const files = require("./routes/files");
app.use("/api/files", files);

//Request and responce for Coupon
const coupon = require("./routes/coupon");
app.use("/api/coupon", coupon);

//Request and responce for Blogs
const blogs = require("./routes/blogs");
app.use("/api/blogs", blogs);

//Request and responce for Support
const support = require("./routes/support");
app.use("/api/support", support);

//Request and responce for Server Info
const serverInfo = require("./routes/settings/server_info");
app.use("/api/server_info", serverInfo);

//Request and responce for WebSocket
const ws = require("./routes/socket");
app.use("/api/socket", ws);

//Request and responce for mail
const mail = require("./routes/settings/mail");
app.use("/api/mail", mail);

//Request and responce for MenuItem
const menuItem = require("./routes/menu_item");
app.use("/api/menu_item", menuItem);

//Request and responce for Settings
const settings = require("./routes/settings/settings");
app.use("/api/settings", settings);

//Request and responce for Comments
const comments = require("./routes/comments");
app.use("/api/comments", comments);

//Request and responce for Orders
const orders = require("./routes/orders");
app.use("/api/orders", orders);

//Profile Request and responce
const profile = require("./routes/profile");
app.use("/api/profile", profile);

//Request and responce for Invoice
const invoice = require("./routes/invoice");
app.use("/api/invoice", invoice);

//Request and responce for Cors
const cors_settings = require("./routes/settings/cors");
app.use("/api/cors", cors_settings);

//Request and responce for Cart
const cart = require("./routes/cart");
app.use("/api/cart", cart);

//Request and responce for Template
const template = require("./routes/settings/template");
app.use("/api/template", template);

//Request and responce for Transcation History
const transactionHistory = require("./routes/transaction_history");
app.use("/api/transaction_history", transactionHistory);

//Request and responce for Payment
const payment = require("./routes/payments/razorpay");
app.use("/api/payment", payment);

//Request and responce for Notifications
const notifications = require("./routes/notifications");
app.use("/api/notifications", notifications); 

//Request and responce for visits 
const visits = require("./routes/statistics/visits");
app.use("/api/visits", visits);

//Request and responce for statistics
const statistics = require("./routes/statistics/statistics");
app.use("/api/statistics", statistics);

//Request and responce for register
const register = require("./routes/register_user");
app.use("/api/register", register); 


app.listen(PORT, () => {
  console.log(`Server is Running on http://localhost:${PORT}`);
});
